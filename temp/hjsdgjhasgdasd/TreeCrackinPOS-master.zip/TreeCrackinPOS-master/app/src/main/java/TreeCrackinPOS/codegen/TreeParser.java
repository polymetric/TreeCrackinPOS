package TreeCrackinPOS.codegen;

import static TreeCrackinPOS.utils.Utils.*;

public class TreeParser {
    public static void main(String[] args) throws Exception {
        String trees = readFileToString("tree_parser_test.txt");
        String[] tokens = trees.split(" ");

        final int LINE_TOKENS = 7;

        for (int i = 0; i < tokens.length; i++) {

        }
    }
}
