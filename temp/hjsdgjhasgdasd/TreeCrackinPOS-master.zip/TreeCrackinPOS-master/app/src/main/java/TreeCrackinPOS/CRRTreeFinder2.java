package TreeCrackinPOS;

public class CRRTreeFinder2 {
    public static void main(String[] args) {
        long inSeed = 36469969418861L;

//        for (int dfzA = 3760; dfzA)
    }
}
