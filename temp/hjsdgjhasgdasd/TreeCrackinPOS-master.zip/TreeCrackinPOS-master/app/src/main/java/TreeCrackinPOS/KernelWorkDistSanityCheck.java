package TreeCrackinPOS;

public class KernelWorkDistSanityCheck {
    public static void main(String[] args) {

    }
}
